<?php

namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://wp-rocket.me/

class WPRocket {
	use SingletonTrait;

	public function __construct() {
		if ( ! class_exists( 'WP_Rocket\Plugin' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'yaycurrency_wprocket_init' ) );
		add_action( 'yaycurrency_deactivate', array( $this, 'overwrite_wprocket_yaycurrency_deactivate' ) );
		add_filter( 'do_rocket_generate_caching_files', '__return_false' );
	}

	public function yaycurrency_wprocket_init() {
		add_filter( 'rocket_cache_dynamic_cookies', array( $this, 'custom_cache_dynamic_cookie' ) );
		add_filter( 'rocket_cache_mandatory_cookies', array( $this, 'custom_cache_mandatory_cookie' ) );
		$this->flush_clean_domain_cache();
	}

	public function overwrite_wprocket_yaycurrency_deactivate() {
		remove_filter( 'rocket_cache_dynamic_cookies', array( $this, 'custom_cache_dynamic_cookie' ) );
		remove_filter( 'rocket_cache_mandatory_cookies', array( $this, 'custom_cache_mandatory_cookie' ) );
		$this->flush_clean_domain_cache();
	}

	public function custom_cache_dynamic_cookie( $cookies ) {
		$cookies[] = YayCurrencyHelper::get_cookie_name();
		return $cookies;
	}

	public function custom_cache_mandatory_cookie( $cookies ) {
		$cookies[] = YayCurrencyHelper::get_cookie_name();
		return $cookies;
	}

	public function flush_clean_domain_cache() {
		if ( ! function_exists( 'rocket_clean_domain' ) ) {
			return false;
		}
		rocket_clean_domain();
	}

}
