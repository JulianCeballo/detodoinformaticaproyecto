<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// link plugin :

class LearnPress {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( class_exists( '\LP_Admin_Assets' ) ) {
			$this->apply_currency = YayCurrencyHelper::detect_current_currency();
			add_filter( 'learn-press/course/price', array( $this, 'custom_course_price' ), 10, 2 );
		}
	}

	public function custom_course_price( $price, $product_id ) {
		$price = YayCurrencyHelper::calculate_price_by_currency_cookie( $price, true, $this->apply_currency );
		$price = YayCurrencyHelper::format_price( $price );
		return $price;
	}
}
