<?php

namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://wordpress.org/plugins/litespeed-cache/

class LiteSpeedCache {
	use SingletonTrait;

	public function __construct() {

		if ( ! defined( 'LSCWP_V' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'remove_all_cache' ) );

	}

	public function remove_all_cache() {

		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}

		if ( function_exists( 'wp_cache_flush_runtime' ) ) {
			wp_cache_flush_runtime();
		}

		do_action( 'litespeed_purge_all' );
	}

}
