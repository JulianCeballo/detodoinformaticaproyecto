<?php
namespace Yay_Currency\Engine;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class Hooks {
	use SingletonTrait;

	public function __construct() {
		// ADD FILTER GET PRICE DEFAULT ON CHECKOUT (APPLY WHEN DISABLE Checkout in different currency OPTION)
		add_filter( 'yay_currency_get_price_default_in_checkout_page', array( $this, 'get_price_default_in_checkout_page' ), 10, 2 );
		// ADD FILTER GET PRICE WITH CONDITIONS
		add_filter( 'yay_currency_get_price_with_conditions', array( $this, 'get_price_with_conditions' ), 10, 3 );
		// ADD FILTER GET PRICE EXCEPT CLASS PLUGINS
		add_filter( 'yay_currency_get_price_except_class_plugins', array( $this, 'get_price_except_class_plugins' ), 10, 3 );
		// ADD FILTER CHECKOUT DIFFERENT CURRENCY
		add_filter( 'yay_currency_checkout_converted_product_subtotal', array( $this, 'checkout_converted_product_subtotal' ), 10, 4 );
		add_filter( 'yay_currency_checkout_converted_cart_subtotal', array( $this, 'checkout_converted_cart_subtotal' ), 10, 4 );
		add_filter( 'yay_currency_checkout_converted_cart_total', array( $this, 'checkout_converted_cart_total' ), 10, 4 );
		add_filter( 'yay_currency_checkout_converted_shipping_method_full_label', array( $this, 'checkout_converted_shipping_method_full_label' ), 10, 5 );
		add_filter( 'yay_currency_checkout_converted_cart_coupon_totals_html', array( $this, 'checkout_converted_cart_coupon_totals_html' ), 10, 4 );
	}

	public function get_price_default_in_checkout_page( $price, $product ) {

		if ( defined( 'THEMECOMPLETE_EPO_PLUGIN_FILE' ) ) {
			$price = apply_filters( 'yay_epo_get_price_dis_checkout_diff_currency', $price, $product );
		}

		if ( defined( 'YITH_WAPO' ) ) {
			$price = apply_filters( 'yay_yith_wapo_get_price_dis_checkout_diff_currency', $price, $product );
		}

		// WooCommerce Subscriptions
		if ( class_exists( 'WC_Subscriptions' ) ) {
			return apply_filters( 'yay_currency_subscription_get_price_renew_default', $price, $product );
		}

		return $price;
	}

	public function get_price_with_conditions( $price, $product, $apply_currency ) {
		// YayExtra , YayPricing
		$is_yaye_adjust_price = false;
		$is_ydp_adjust_price  = false;
		$caculate_price       = YayCurrencyHelper::calculate_price_by_currency( $price, false, $apply_currency );
		if ( class_exists( '\YayExtra\Classes\ProductPage' ) ) {
			$is_yaye_adjust_price = apply_filters( 'yaye_check_adjust_price', false );
		}
		if ( class_exists( '\YayPricing\FrontEnd\ProductPricing' ) ) {
			$is_ydp_adjust_price = apply_filters( 'ydp_check_adjust_price', false );
		}

		if ( class_exists( '\YayPricing\FrontEnd\ProductPricing' ) && $is_ydp_adjust_price ) {
			if ( class_exists( '\YayExtra\Classes\ProductPage' ) && $is_yaye_adjust_price ) {
				return $price;
			} else {
				return $caculate_price;
			}
		}
		if ( class_exists( '\YayExtra\Classes\ProductPage' ) ) {
			//Active Woo Discount Rules PRO plugin and apply discount
			if ( defined( 'WDR_PRO_VERSION' ) && isset( $product->awdr_discount_price ) ) {
				$price = $product->awdr_discount_price;
			} else {
				$price = apply_filters( 'yay_currency_extra_get_price_with_options', false, $product );
			}

			if ( ! $price ) {
				return $product->get_price( 'edit' );
			}
			return $price;
		}
		// Compatible with Tiered Pricing Table for WooCommerce plugin
		if ( class_exists( 'TierPricingTable\TierPricingTablePlugin' ) ) {
			if ( isset( $product->get_changes()['price'] ) ) {
				return $product->get_changes()['price'];
			}
		}

		// WooCommerce TM Extra Product Options
		if ( defined( 'THEMECOMPLETE_EPO_PLUGIN_FILE' ) ) {
			return apply_filters( 'yay_epo_get_price_with_options', false, $product );
		}

		// WooCommerce WPFunnels
		if ( defined( 'WPFNL_VERSION' ) ) {
			$price = apply_filters( 'yay_wpfunnels_get_price', false, $product );
			return $price;
		}

		// Advanced Product Fields Pro (Extended) for WooCommerce
		if ( class_exists( '\SW_WAPF_PRO\WAPF' ) ) {
			return apply_filters( 'yay_wapf_get_price_with_options', false, $product );
		}

		// YITH WooCommerce Product Add-ons & Extra Options Premium
		if ( defined( 'YITH_WAPO' ) ) {
			return apply_filters( 'yay_yith_wapo_get_price_with_options', false, $product );
		}

		// Woo Discount Rules PRO
		if ( defined( 'WDR_PRO_VERSION' ) && defined( 'WDR_VERSION' ) ) {
			return apply_filters( 'yay_discount_rules_get_price_with_options', false, $product );
		}

		// WooCommerce Subscriptions
		if ( class_exists( 'WC_Subscriptions' ) ) {
			return apply_filters( 'yay_currency_subscription_get_price_renew', false, $product );
		}

		return false;

	}

	public function get_price_except_class_plugins( $price, $product, $apply_currency ) {
		$caculate_price       = YayCurrencyHelper::calculate_price_by_currency( $price, false, $apply_currency );
		$except_class_plugins = array(
			'WC_Measurement_Price_Calculator',
			'Cartflows_Checkout',
			'\WP_Grid_Builder\Includes\Plugin',
			'WCPA', // Woocommerce Custom Product Addons
			'\Acowebs\WCPA\Main', // Woocommerce Custom Product Addons
			'WoonpCore', // Name Your Price for WooCommerce
			'Webtomizer\\WCDP\\WC_Deposits', // WooCommerce Deposits
			'\WC_Product_Price_Based_Country', // Price Per Country
			'\JET_APB\Plugin', // Jet Appointments Booking
		);
		$except_class_plugins = apply_filters( 'yay_currency_except_class_plugin', $except_class_plugins );
		foreach ( $except_class_plugins as $class ) {
			if ( class_exists( $class ) ) {
				return $caculate_price;
			}
		}
		return false;
	}

	public function checkout_converted_product_subtotal( $product_subtotal, $product_price, $fallback_currency, $apply_currency ) {
		$original_product_subtotal  = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $product_price );
		$converted_product_subtotal = YayCurrencyHelper::calculate_price_by_currency_html( $apply_currency, $product_price );
		$product_subtotal           = $original_product_subtotal . ' (~' . $converted_product_subtotal . ')';
		return $product_subtotal;
	}

	public function checkout_converted_cart_subtotal( $cart_subtotal, $subtotal_price, $fallback_currency, $apply_currency ) {
		$original_subtotal  = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $subtotal_price );
		$converted_subtotal = YayCurrencyHelper::calculate_price_by_currency_html( $apply_currency, $subtotal_price );
		$cart_subtotal      = $original_subtotal . ' (~' . $converted_subtotal . ')';
		return $cart_subtotal;
	}

	public function checkout_converted_cart_total( $cart_total, $total_price, $fallback_currency, $apply_currency ) {
		$original_total  = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $total_price );
		$converted_total = YayCurrencyHelper::calculate_price_by_currency_html( $apply_currency, $total_price );
		$cart_total      = $original_total . ' (~' . $converted_total . ')';
		return $cart_total;
	}

	public function checkout_converted_shipping_method_full_label( $label, $method_label, $shipping_fee, $fallback_currency, $apply_currency ) {
		$converted_shipping_fee                   = YayCurrencyHelper::calculate_price_by_currency( $shipping_fee, true, $apply_currency );
		$formatted_shipping_fee                   = YayCurrencyHelper::format_price( $converted_shipping_fee );
		$formatted_fallback_currency_shipping_fee = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $shipping_fee );
		$label                                    = '' . $method_label . ': ' . $formatted_fallback_currency_shipping_fee . ' (~' . $formatted_shipping_fee . ')';
		return $label;
	}

	public function checkout_converted_cart_coupon_totals_html( $coupon_html, $coupon, $fallback_currency, $apply_currency ) {

		$discount_totals          = WC()->cart->get_coupon_discount_totals();
		$discount_price           = $discount_totals[ $coupon->get_code() ];
		$converted_discount_price = YayCurrencyHelper::calculate_price_by_currency( $discount_price, true, $apply_currency );
		$discount_amount_html     = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $discount_price );
		$formatted_discount_price = YayCurrencyHelper::format_price( $converted_discount_price );

		$custom_coupon_html = '-' . $discount_amount_html . ' (~' . $formatted_discount_price . ')' . substr( $coupon_html, strpos( $coupon_html, '<a' ) ) . '';
		return $custom_coupon_html;
	}

}
