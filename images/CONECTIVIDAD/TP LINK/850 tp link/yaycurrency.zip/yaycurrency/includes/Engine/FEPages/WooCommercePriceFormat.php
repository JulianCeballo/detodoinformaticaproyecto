<?php

namespace Yay_Currency\Engine\FEPages;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class WooCommercePriceFormat {
	use SingletonTrait;

	private $converted_currency = array();
	private $apply_currency     = array();

	private $is_dis_checkout_diff_currency = false;

	public function __construct() {
		add_action( 'init', array( $this, 'wp_load' ) );
	}

	public function wp_load() {
		if ( ! is_admin() ) {
			$this->converted_currency            = YayCurrencyHelper::converted_currency();
			$this->apply_currency                = YayCurrencyHelper::get_apply_currency( $this->converted_currency );
			$is_checkout_different_currency      = get_option( 'yay_currency_checkout_different_currency', 0 );
			$this->is_dis_checkout_diff_currency = YayCurrencyHelper::is_dis_checkout_diff_currency( $is_checkout_different_currency, $this->apply_currency['status'] );
			add_filter( 'woocommerce_currency', array( $this, 'change_woocommerce_currency' ), 10, 1 );
			add_filter( 'woocommerce_currency_symbol', array( $this, 'change_existing_currency_symbol' ), 10, 2 );
			add_filter( 'pre_option_woocommerce_currency_pos', array( $this, 'change_currency_position' ) );
			add_filter( 'wc_get_price_thousand_separator', array( $this, 'change_thousand_separator' ) );
			add_filter( 'wc_get_price_decimal_separator', array( $this, 'change_decimal_separator' ) );
			add_filter( 'wc_get_price_decimals', array( $this, 'change_number_decimals' ) );

		}
	}

	public function change_woocommerce_currency( $currency ) {

		if ( ! $this->apply_currency || ( is_checkout() && $this->is_dis_checkout_diff_currency ) ) {
			return $currency;
		}

		if ( isset( $this->apply_currency['currency'] ) ) {
			$currency = $this->apply_currency['currency'];
		}

		return $currency;
	}

	public function change_existing_currency_symbol( $currency_symbol, $currency ) {

		$currency_unit_type = get_option( 'yay_currency_currency_unit_type', 'symbol' );

		if ( 'symbol' === $currency_unit_type ) {
			if ( '&#36;' === $currency_symbol ) { // if symbol is '$', concat it with currency code
				$currency_symbol = $currency . $currency_symbol;
			}
		} else {
			$currency_symbol = $currency;
		}

		if ( ! $this->apply_currency ) {
			return $currency_symbol;
		}

		if ( ( is_checkout() && ( $this->is_dis_checkout_diff_currency || ! empty( is_wc_endpoint_url( 'order-received' ) ) ) ) || ( function_exists( 'is_account_page' ) && is_account_page() ) ) {
			$currency_symbol = apply_filters( 'yay_currency_woocommerce_currency_symbol', $currency_symbol );
			return $currency_symbol;
		}

		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return $currency_symbol;
		}

		if ( 'symbol' === $currency_unit_type ) {
			$currency_symbol = $currency === $this->apply_currency['currency'] ? $this->apply_currency['symbol'] : YayCurrencyHelper::get_symbol_by_currency( $currency, $this->converted_currency );
			if ( '&#36;' === $currency_symbol ) { // if symbol is '$', concat it with currency code
				$currency_symbol = $currency . $currency_symbol;
			}
			return wp_kses_post( html_entity_decode( $currency_symbol ) );
		}
		$currency_symbol = $this->apply_currency['currency'];
		return wp_kses_post( html_entity_decode( $currency_symbol ) );
	}

	public function change_currency_position() {
		return Helper::change_currency_position( $this->apply_currency );
	}

	public function change_thousand_separator() {
		return Helper::change_thousand_separator( $this->apply_currency );
	}

	public function change_decimal_separator() {
		return Helper::change_decimal_separator( $this->apply_currency );
	}

	public function change_number_decimals() {
		return Helper::change_number_decimals( $this->apply_currency );
	}


}
