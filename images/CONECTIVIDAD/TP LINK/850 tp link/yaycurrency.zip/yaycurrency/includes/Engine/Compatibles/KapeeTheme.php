<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;

use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class KapeeTheme {

	use SingletonTrait;

	public function __construct() {
		// Compatible with Kapee theme
		if ( 'kapee' === wp_get_theme()->template ) {
			add_filter( 'woocommerce_get_price_html', array( $this, 'custom_price_html' ), 10, 2 );
		}

	}

	public function custom_price_html( $price, $product ) {
		$converted_price = YayCurrencyHelper::calculate_price_by_currency_cookie( $product->get_price( 'edit' ) );
		$formatted_price = YayCurrencyHelper::format_price( $converted_price );
		return $formatted_price;
	}
}
