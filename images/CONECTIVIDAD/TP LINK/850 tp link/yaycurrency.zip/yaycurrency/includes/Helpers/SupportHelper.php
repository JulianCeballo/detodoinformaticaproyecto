<?php
namespace Yay_Currency\Helpers;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;


class SupportHelper {

	use SingletonTrait;

	protected function __construct() {}

	public static function get_price_options_by_3rd_plugin( $product ) {
		$price_options = 0;
		//WooCommerce Product Add-ons plugin
		if ( defined( 'WC_PRODUCT_ADDONS_VERSION' ) ) {
			if ( isset( $product->yay_currency_addon_set_options_price ) ) {
				$price_options = $product->yay_currency_addon_set_options_price;
			}
		}
		//WooCommerce TM Extra Product Options
		if ( defined( 'THEMECOMPLETE_EPO_PLUGIN_FILE' ) ) {
			if ( isset( $product->tm_epo_set_options_price ) ) {
				$price_options = $product->tm_epo_set_options_price;
			}
		}
		//YayExtra
		if ( defined( 'YAYE_VERSION' ) ) {
			if ( isset( $product->yay_currency_extra_set_options_price ) ) {
				$price_options = $product->yay_currency_extra_set_options_price;
			}
		}

		return $price_options;
	}

	public static function get_product_price( $product_id, $apply_currency = false ) {
		$wc_product    = wc_get_product( $product_id );
		$product_price = $wc_product->get_price( 'edit' );
		if ( $apply_currency ) {
			$product_price = YayCurrencyHelper::calculate_price_by_currency( $product_price, true, $apply_currency );
		}
		return $product_price;
	}

	public static function set_price_options_by_wc_cart_contents( $apply_currency ) {
		$cart_contents = WC()->cart->get_cart_contents();
		if ( count( $cart_contents ) > 0 ) {
			foreach ( $cart_contents  as $key => $cart_item ) {
				$product_obj   = $cart_item['data'];
				$product_id    = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
				$product_price = self::get_product_price( $product_id, $apply_currency );
				if ( defined( 'WC_PRODUCT_ADDONS_VERSION' ) ) {
					apply_filters( 'yay_currency_addon_set_price_options_by_cart_item', $cart_item, $product_price, $product_obj, $apply_currency );
				}
			}
		}

	}

	// GET PRICE SIGNUP FEE (WooCommerce Subscriptions plugin)
	public static function get_price_sign_up_fee_by_wc_subscriptions( $apply_currency, $product_obj ) {
		$sign_up_fee = 0;
		if ( ! class_exists( 'WC_Subscriptions' ) ) {
			return $sign_up_fee;
		}
		if ( class_exists( 'WC_Subscriptions_Product' ) ) {
			$sign_up_fee = \WC_Subscriptions_Product::get_sign_up_fee( $product_obj );
			if ( $sign_up_fee > 0 ) {
				$sign_up_fee = YayCurrencyHelper::calculate_price_by_currency( $sign_up_fee, true, $apply_currency );
			}
		}
		return $sign_up_fee;
	}

}
