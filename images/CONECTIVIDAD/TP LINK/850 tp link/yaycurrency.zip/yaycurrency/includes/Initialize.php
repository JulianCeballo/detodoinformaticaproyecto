<?php
namespace Yay_Currency;

use Yay_Currency\Utils\SingletonTrait;

/**
 * Yay_Currency Plugin Initializer
 */
class Initialize {

	use SingletonTrait;

	/**
	 * The Constructor that load the engine classes
	 */
	protected function __construct() {
		// Engine
		\Yay_Currency\Engine\Hooks::get_instance();
		\Yay_Currency\Engine\Ajax::get_instance();

		// BEPages
		\Yay_Currency\Engine\BEPages\Settings::get_instance();
		\Yay_Currency\Engine\BEPages\WooCommerceSettingGeneral::get_instance();
		\Yay_Currency\Engine\BEPages\FixedPricesPerProduct::get_instance();
		\Yay_Currency\Engine\BEPages\WooCommerceFilterReport::get_instance();
		\Yay_Currency\Engine\BEPages\WooCommerceOrderAdmin::get_instance();

		// // Appearance
		\Yay_Currency\Engine\Appearance\MenuDropdown::get_instance();
		\Yay_Currency\Engine\Appearance\Widget::get_instance();

		// // FEPages
		\Yay_Currency\Engine\FEPages\WooCommerceCurrency::get_instance();
		\Yay_Currency\Engine\FEPages\WooCommercePriceFormat::get_instance();
		\Yay_Currency\Engine\FEPages\SingleProductDropdown::get_instance();
		\Yay_Currency\Engine\FEPages\Shortcodes::get_instance();

		// Compatibles
		\Yay_Currency\Engine\Compatibles\RapydPaymentGateway::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceSimpleAuctions::get_instance();

		\Yay_Currency\Engine\Compatibles\BlocksyTheme::get_instance();
		\Yay_Currency\Engine\Compatibles\CartflowsOrBeTheme::get_instance();
		\Yay_Currency\Engine\Compatibles\KapeeTheme::get_instance();
		\Yay_Currency\Engine\Compatibles\JulyTheme::get_instance();

		\Yay_Currency\Engine\Compatibles\AdvancedProductFieldsProWooCommerce::get_instance();
		\Yay_Currency\Engine\Compatibles\B2BMarket::get_instance();
		\Yay_Currency\Engine\Compatibles\B2BKingPro::get_instance();

		\Yay_Currency\Engine\Compatibles\FlexibleShipping::get_instance();
		\Yay_Currency\Engine\Compatibles\HivePress::get_instance();

		\Yay_Currency\Engine\Compatibles\TieredPricingTableForWooCommerce::get_instance();
		\Yay_Currency\Engine\Compatibles\JetSmartFilters::get_instance();

		\Yay_Currency\Engine\Compatibles\WPGridBuilderCaching::get_instance();
		\Yay_Currency\Engine\Compatibles\WPRocket::get_instance();
		\Yay_Currency\Engine\Compatibles\LiteSpeedCache::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceProductFeed::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommercePayForPayment::get_instance();

		\Yay_Currency\Engine\Compatibles\WooCommerceQuickView::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceTableRateShipping::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceSimpleAuction::get_instance();
		\Yay_Currency\Engine\Compatibles\WPFunnels::get_instance();
		\Yay_Currency\Engine\Compatibles\LearnPress::get_instance();

		\Yay_Currency\Engine\Compatibles\WooCommerceProductAddons::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceTMExtraProductOptions::get_instance();
		\Yay_Currency\Engine\Compatibles\YITHWooCommerceAddOnsExtraPremiumOptions::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceProductBundles::get_instance();
		\Yay_Currency\Engine\Compatibles\WooCommerceSubscriptions::get_instance();
		\Yay_Currency\Engine\Compatibles\WooDiscountRulesPro::get_instance();

		\Yay_Currency\Engine\Compatibles\WooCommerceTeraWallet::get_instance();
		\Yay_Currency\Engine\Compatibles\YITHEasyOrderPageForWooCommerce::get_instance();
		\Yay_Currency\Engine\Compatibles\YITHPointsAndRewards::get_instance();
		\Yay_Currency\Engine\Compatibles\YITHWoocommerceGiftCards::get_instance();

	}
}
